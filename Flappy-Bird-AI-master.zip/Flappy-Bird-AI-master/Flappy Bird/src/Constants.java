
public class Constants {
	
	static float BIRD_STAR_X = 280;
	static float FIRST_PIPE_X = 600;
	static float EACH_PIPE_SPACE = 250;
	static float PIPE_WIDTH = 110;
	static int POPULATION_SIZE = 200;
	static boolean isDraw = true;
	
	static int gameHeight = 600;
	
}
